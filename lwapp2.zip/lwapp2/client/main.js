var app = new WebSocketApp();
initWs(app);

ReactDOM.render(<App/>, document.getElementById('root'));